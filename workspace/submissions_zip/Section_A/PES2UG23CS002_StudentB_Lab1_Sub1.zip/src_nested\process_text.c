#include "process_text.h"
#include <string.h>
#include <ctype.h>

void word_to_lower(char *str) {
    for (int i = 0; str[i] != '\0'; i++) {
        str[i] = (char)tolower((unsigned char)str[i]);
    }
}

void process_line(TrieNode *root, char *line) {
    const char *delim = " \t\r\n.,;:!?\"'()";
    char *token = strtok(line, delim);
    while (token != NULL) {
        if (strlen(token) > 0) {
            word_to_lower(token);
            insert(root, token);
        }
        token = strtok(NULL, delim);
    }
}