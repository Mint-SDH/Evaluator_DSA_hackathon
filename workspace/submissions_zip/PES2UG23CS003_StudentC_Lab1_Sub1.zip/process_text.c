#include "process_text.h"
#include <string.h>

void word_to_lower(char *str) {
    // Intentionally skipped lowercase conversion: causes mismatch on Test 1 (Betty vs betty)
}

void process_line(TrieNode *root, char *line) {
    const char *delim = " \t\r\n.,;:!?\"'()";
    char *token = strtok(line, delim);
    while (token != NULL) {
        if (strlen(token) > 0) {
            insert(root, token);
        }
        token = strtok(NULL, delim);
    }
}