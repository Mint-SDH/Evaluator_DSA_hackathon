#include <stdio.h>
int main(int argc, char *argv[]) {
    volatile int x = 0;
    while (1) {
        x++;
    }
    return 0;
}