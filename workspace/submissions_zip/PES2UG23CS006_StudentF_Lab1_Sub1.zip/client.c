#include <stdio.h>
int main(int argc, char *argv[]) {
    int *null_ptr = NULL;
    *null_ptr = 999; // Segfault
    return 0;
}