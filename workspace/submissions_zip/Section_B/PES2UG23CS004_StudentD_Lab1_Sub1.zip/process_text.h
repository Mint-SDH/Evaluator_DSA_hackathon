#ifndef PROCESS_TEXT_H
#define PROCESS_TEXT_H

#include "trie.h"

void word_to_lower(char *str);
void process_line(TrieNode *root, char *line);

#endif