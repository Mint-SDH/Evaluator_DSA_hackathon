#include "process_text.h"
#include <string.h>

// Missing implementation of word_to_lower to demonstrate linker error extraction

void process_line(TrieNode *root, char *line) {
    const char *delim = " \t\r\n";
    char *token = strtok(line, delim);
    while (token != NULL) {
        word_to_lower(token); // Undefined reference at link time
        insert(root, token);
        token = strtok(NULL, delim);
    }
}