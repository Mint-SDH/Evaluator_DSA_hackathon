#include "mylist.h"
void init_list(void) {}