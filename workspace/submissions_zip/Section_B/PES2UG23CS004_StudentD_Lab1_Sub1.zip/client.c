#include <stdio.h>
#include <stdlib.h>
#include "trie.h"
#include "process_text.h"
#include "mylist.h"

int main(int argc, char *argv[]) {
    const char *filename = (argc > 1) ? argv[1] : "input1.txt";
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        fprintf(stderr, "Cannot open file %s\n", filename);
        return 1;
    }

    TrieNode *root = create_node();
    init_list();

    char line[1024];
    while (fgets(line, sizeof(line), fp)) {
        process_line(root, line);
    }
    fclose(fp);

    display_trie(root);
    free_trie(root);
    return 0;
}