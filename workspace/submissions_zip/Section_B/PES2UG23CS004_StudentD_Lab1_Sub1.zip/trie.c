#include "trie.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

TrieNode* create_node(void) {
    TrieNode *node = (TrieNode*)calloc(1, sizeof(TrieNode));
    node->count = 0;
    node->is_end = 0;
    return node;
}

void insert(TrieNode *root, const char *word) {
    TrieNode *curr = root;
    for (int i = 0; word[i] != '\0'; i++) {
        char c = word[i];
        if (c >= 'A' && c <= 'Z') c = c - 'A' + 'a';
        if (c < 'a' || c > 'z') continue;
        int idx = c - 'a';
        if (!curr->children[idx]) {
            curr->children[idx] = create_node();
        }
        curr = curr->children[idx];
    }
    curr->is_end = 1;
    curr->count++;
}

static void display_helper(TrieNode *node, char *buffer, int depth) {
    if (!node) return;
    if (node->is_end) {
        buffer[depth] = '\0';
        printf("word : %s count : %d\n", buffer, node->count);
    }
    for (int i = 0; i < 26; i++) {
        if (node->children[i]) {
            buffer[depth] = 'a' + i;
            display_helper(node->children[i], buffer, depth + 1);
        }
    }
}

void display_trie(TrieNode *root) {
    char buffer[256];
    display_helper(root, buffer, 0);
}

void free_trie(TrieNode *root) {
    if (!root) return;
    for (int i = 0; i < 26; i++) {
        if (root->children[i]) {
            free_trie(root->children[i]);
        }
    }
    free(root);
}