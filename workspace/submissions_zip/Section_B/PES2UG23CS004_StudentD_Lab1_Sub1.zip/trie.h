#ifndef TRIE_H
#define TRIE_H

typedef struct TrieNode {
    int count;
    int is_end;
    struct TrieNode *children[26];
} TrieNode;

TrieNode* create_node(void);
void insert(TrieNode *root, const char *word);
void display_trie(TrieNode *root);
void free_trie(TrieNode *root);

#endif