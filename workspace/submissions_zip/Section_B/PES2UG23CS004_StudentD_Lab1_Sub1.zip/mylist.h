#ifndef MYLIST_H
#define MYLIST_H
void init_list(void);
#endif